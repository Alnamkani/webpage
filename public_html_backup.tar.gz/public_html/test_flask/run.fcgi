#!/home/a/al/alnamkani/app/venv/bin/python
import os
import sys

sys.path.insert(0, os.path.expanduser('~/app'))
from flup.server.fcgi import WSGIServer
from myapp.app import app

if __name__ == '__main__':
    WSGIServer(app).run()
